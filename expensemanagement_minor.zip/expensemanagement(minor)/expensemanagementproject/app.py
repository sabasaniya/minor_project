import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from database import insert_expense, get_expenses, get_expenses_by_date

st.set_page_config(page_title="💰 Expense Manager", layout="wide")

st.title("💰 Expense Management System")

menu = ["Add Expense", "View Expenses", "Analytics", "Search by Date"]
choice = st.sidebar.selectbox("Select an option", menu)

if choice == "Add Expense":
    st.subheader("➕ Add New Expense")
    name = st.text_input("Expense Name")
    amount = st.number_input("Amount", min_value=0.0, format="%.2f")
    category = st.selectbox("Category", ["Food", "Travel", "Shopping", "Bills", "Other"])
    date = st.date_input("Date")

    if st.button("Add Expense"):
        insert_expense(name, amount, category, str(date))
        st.success("Expense added successfully!")

elif choice == "View Expenses":
    st.subheader("📋 Expense Records")
    expenses = get_expenses()
    if expenses:
        df = pd.DataFrame(expenses)
        st.dataframe(df)

        if st.button("Refresh"):
            st.experimental_rerun()
    else:
        st.warning("No expenses found.")

elif choice == "Analytics":
    st.subheader("📊 Expense Analytics")
    expenses = get_expenses()

    if expenses:
        df = pd.DataFrame(expenses)
        df["date"] = pd.to_datetime(df["date"])

        # Daily, Monthly, Yearly Analytics
        daily_expenses = df.groupby(df["date"].dt.date)["amount"].sum().reset_index()
        df["month"] = df["date"].dt.to_period("M").astype(str)
        monthly_expenses = df.groupby("month")["amount"].sum().reset_index()
        df["year"] = df["date"].dt.year
        yearly_expenses = df.groupby("year")["amount"].sum().reset_index()

        col1, col2 = st.columns(2)

        with col1:
            st.write("### Total Expenses: ₹", df["amount"].sum())

            st.write("### Category-wise Expenses")
            category_chart = df.groupby("category")["amount"].sum().reset_index()
            fig, ax = plt.subplots(figsize=(6, 4))
            sns.barplot(x="amount", y="category", data=category_chart, ax=ax)
            st.pyplot(fig)

        with col2:
            st.write("### Monthly Expense Trend")
            fig, ax = plt.subplots(figsize=(6, 4))
            sns.lineplot(x="month", y="amount", data=monthly_expenses, marker="o", ax=ax)
            plt.xticks(rotation=45)
            st.pyplot(fig)

        st.write("### Daily Expenses Over Time")
        fig, ax = plt.subplots(figsize=(10, 4))
        sns.lineplot(x="date", y="amount", data=daily_expenses, marker="o", ax=ax)
        plt.xticks(rotation=45)
        st.pyplot(fig)

        st.write("### Yearly Expense Summary")
        st.bar_chart(yearly_expenses.set_index("year"))

    else:
        st.warning("No data available for analytics.")

elif choice == "Search by Date":
    st.subheader("🔍 Search Expenses by Date")
    search_date = st.date_input("Select a Date to View Expenses")
    if st.button("Search"):
        result = get_expenses_by_date(str(search_date))
        if result:
            df = pd.DataFrame(result)
            st.write(f"### Expenses on {search_date}")
            st.dataframe(df)
        else:
            st.warning("No expenses found for the selected date.")

# Export to CSV
if st.sidebar.button("Export to CSV"):
    expenses = get_expenses()
    if expenses:
        df = pd.DataFrame(expenses)
        csv = df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Download CSV",
            data=csv,
            file_name='expenses.csv',
            mime='text/csv',
        )
    else:
        st.warning("No expenses to export.")
