from pymongo import MongoClient
from datetime import datetime

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["expense_manager"]
collection = db["expenses"]


def insert_expense(name: str, amount: float, category: str, date_str: str) -> None:
    """Insert an expense into the database. Expects date_str in 'YYYY-MM-DD' format."""
    try:
        # Validate date format
        datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        raise ValueError("Date must be in 'YYYY-MM-DD' format")

    expense = {
        "name": name,
        "amount": amount,
        "category": category,
        "date": date_str
    }
    collection.insert_one(expense)


def get_expenses() -> list:
    """Retrieve all expenses from the database."""
    return list(collection.find({}, {"_id": 0}))


def get_expenses_by_date(date_str: str) -> list:
    """Retrieve all expenses for a specific date (YYYY-MM-DD)."""
    # Ensure date_str is valid
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        raise ValueError("Date must be in 'YYYY-MM-DD' format")
    return list(collection.find({"date": date_str}, {"_id": 0}))


def delete_expense(name: str) -> None:
    """Delete an expense by name."""
    collection.delete_one({"name": name})


def update_expense(name: str, new_amount: float = None, new_category: str = None, new_date_str: str = None) -> None:
    """
    Update fields of an expense by name.
    Only non-None arguments will be updated.
    Expects new_date_str in 'YYYY-MM-DD' format if provided.
    """
    update_fields = {}
    if new_amount is not None:
        update_fields["amount"] = new_amount
    if new_category:
        update_fields["category"] = new_category
    if new_date_str:
        try:
            datetime.strptime(new_date_str, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Date must be in 'YYYY-MM-DD' format")
        update_fields["date"] = new_date_str

    if update_fields:
        collection.update_one({"name": name}, {"$set": update_fields})
